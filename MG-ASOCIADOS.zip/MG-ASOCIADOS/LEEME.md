# MG Asociados

Página estática en HTML, CSS y JavaScript. No requiere npm, compilación ni claves.

## Abrir la página

Descomprime el ZIP y abre `MG-ASOCIADOS/index.html` en Chrome. Conserva la carpeta
`assets` junto al HTML: contiene las imágenes, iconos, estilos y tipografías.

Para trabajar con un servidor local, desde la carpeta `MG-ASOCIADOS` ejecuta:

```bash
python3 -m http.server 8000 --bind 127.0.0.1
```

## Editar las nuevas secciones

- `index.html`: textos y enlaces de Filosofía, Contacto y pie de página.
- `assets/css/sections.css`: estilos adaptables y tipografías locales.
- `assets/css/tablet.css`: composición de tabletas entre 600 y 1200 px; el diseño de referencia es de 768 px de ancho.
- `assets/css/header.css`: proporciones del encabezado, posición fija y sección activa.
- `assets/icons/`: iconos SVG originales.
- `assets/images/`: fotografías y fondos de Contacto, incluido `Fondo_contacto_tabletas.png` (768 × 242 px).
- `assets/fonts/`: Cormorant Garamond y DM Sans del repositorio oficial
  `google/fonts`, junto con sus licencias OFL.

Para añadir otro PNG o SVG, guárdalo en la carpeta correspondiente y referencia
su ruta desde el HTML, por ejemplo:

```html
<img src="assets/images/mi-imagen.png" alt="Descripción de la imagen">
```

Dentro de `assets/css/sections.css`, las rutas parten de la carpeta CSS; por
ejemplo, `url("../images/Fondo_contacto.png")`.

## Datos de contacto

- WhatsApp: https://wa.me/529981566796
- Teléfono: +52 998 156 6796
- Correo: c.p.arturomendez@mgasociados.net
- Facebook: https://www.facebook.com/profile.php?id=61595373060384
- Instagram: icono preparado, sin enlace hasta que exista el perfil oficial.

Para activar Instagram, sustituye el `span` que contiene su icono por:

```html
<a href="URL_DEL_PERFIL_OFICIAL" target="_blank" rel="noopener noreferrer"
   aria-label="MG Asociados en Instagram">
  <img src="assets/icons/Icon_Instagram.svg" alt="" width="38" height="38">
</a>
```

La composición móvil muestra solo los nombres de los principios, el botón de
WhatsApp y el footer compacto; la versión de escritorio añade las descripciones,
el fondo de Contacto y los datos del despacho.

La composición de tabletas usa el diseño vertical proporcionado: encabezado de
80 px con menú, contenido centrado, tarjetas de servicio en una columna,
principios en una lista y el fondo específico de Contacto. Se adapta también a
tabletas horizontales sin fijar la altura de las secciones.

Los bloques de la página aparecen suavemente al desplazarse. Si el sistema
prefiere reducir el movimiento, el contenido se muestra sin animación.

El encabezado muestra la sección actual al desplazarse. En escritorio conserva
los tres enlaces del diseño original; al entrar en Filosofía se resalta
**Nosotros** y se muestra el nombre de la sección. En móvil y tableta aparece
solo el logotipo y el botón de menú, sin indicador de sección activa.

En escritorio, el encabezado se oculta suavemente después de 3 segundos sin
actividad. Vuelve a aparecer al desplazarse o al acercar el cursor al borde
superior, y permanece visible mientras se usa el menú.

## Subir los cambios a GitHub

Desde el repositorio, usa **Add file → Upload files** y arrastra el contenido de
esta carpeta, incluido `assets`. Para servir el sitio desde la raíz, `index.html`
y `assets` deben quedar juntos en esa raíz. Subir únicamente el ZIP guarda una
copia descargable, pero no publica por sí mismo la página.
